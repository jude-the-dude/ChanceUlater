package com.example.jude.chanceulater

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private var number = 8000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun flipCoin(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val result = if (Random.nextBoolean()) "Heads" else "Tails"
        resultTextView.text = result
    }

    fun rollSixSidedDie(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val result = (Random.nextInt(6) + 1).toString()
        resultTextView.text = result
    }

    fun rollTwentySidedDie(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val result = (Random.nextInt(20) + 1).toString()
        resultTextView.text = result
    }

    fun playRockPaperScissors(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val options = arrayOf("Rock", "Paper", "Scissors")
        val result = options[Random.nextInt(options.size)]
        resultTextView.text = result
    }

    fun add(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val numberEditText: EditText = findViewById(R.id.numberEditText)
        val input = numberEditText.text.toString()
        if (input.isNotEmpty()) {
            val num = input.toInt()
            number += num
            resultTextView.text = number.toString()
        }
    }

    fun subtract(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        val numberEditText: EditText = findViewById(R.id.numberEditText)
        val input = numberEditText.text.toString()
        if (input.isNotEmpty()) {
            val num = input.toInt()
            number -= num
            if (number <= 0) {
                resultTextView.text = "You lost the game"
            } else {
                resultTextView.text = number.toString()
            }
        }
    }

    fun divideByTwo(view: View) {
        val resultTextView: TextView = findViewById(R.id.resultTextView)
        number /= 2
        resultTextView.text = number.toString()
    }
}